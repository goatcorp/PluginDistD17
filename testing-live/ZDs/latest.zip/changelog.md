# 1.0.0.1
- Fixed BRD Bloodletter under Mage's Ballad and MCH Heat Blast affecting the cooldown of Gauss Round and Ricochet.  

# 1.0.0.1
- Fixed most abilities with shared charges aside from BLU from not properly being tracked.
- Remove NIN Mudras from the timeline when Hide is used.

# 1.0.0.0
- First release.