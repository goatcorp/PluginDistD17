using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace XIVControllerToggle {
    internal static class Extensions {

        public static float abs(this float input) {
            return Math.Abs(input);
        }
    }
}
