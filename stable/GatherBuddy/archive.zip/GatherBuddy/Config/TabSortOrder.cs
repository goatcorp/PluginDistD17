﻿namespace GatherBuddy.Config;

public enum TabSortOrder
{
    ItemFishWeather,
    ItemWeatherFish,
    FishNodeWeather,
    FishWeatherItem,
    WeatherFishItem,
    WeatherItemFish,
}
