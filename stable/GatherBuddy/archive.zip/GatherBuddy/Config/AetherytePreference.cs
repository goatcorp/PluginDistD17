﻿namespace GatherBuddy.Config;

public enum AetherytePreference : byte
{
    Cost,
    Distance,
}
