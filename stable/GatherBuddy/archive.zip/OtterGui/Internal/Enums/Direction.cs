namespace OtterGui.Internal.Enums;

public enum Direction : uint
{}
