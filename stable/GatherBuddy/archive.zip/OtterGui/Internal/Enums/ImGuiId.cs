namespace OtterGui.Internal.Enums;

public enum ImGuiId : uint
{ }
