namespace OtterGui.Internal.Enums;

public enum ChildFlags : uint
{ }
