namespace OtterGui.Internal.Enums;

public enum NavHighlightFlags : uint
{ }
