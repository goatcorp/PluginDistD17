# GatherBuddy
Dalamud-based FFXIV addon to simplify gathering.
