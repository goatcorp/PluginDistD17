import{l as o,a as r}from"../chunks/eqxL1G8_.js";export{o as load_css,r as start};
