﻿namespace KamiLib.AutomaticUserInterface;

public class FunctionAttributeBase : AttributeBase
{
}