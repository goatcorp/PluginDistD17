﻿using System;

namespace KamiLib.AutomaticUserInterface;

public class DisabledAttribute : Attribute
{
}