﻿namespace KamiLib.Interfaces;

public interface IDrawable
{
    void Draw();
}