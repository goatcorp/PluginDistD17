# CurrencyAlert
[![Download count](https://img.shields.io/endpoint?url=https://qzysathwfhebdai6xgauhz4q7m0mzmrf.lambda-url.us-east-1.on.aws/CurrencyAlert)](https://github.com/MidoriKami/CurrencyAlert)
