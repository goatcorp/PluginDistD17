# FFXIVPetRenamer
Give cute nicknames to your FFXIV companions.

### Tutorial
Type [/petname] to open the pet settings. The following panel will show.

![](https://github.com/Glyceri/FFXIVPetRenamer/blob/main/res/EmptyPanel.png)

Summon any companion and the panel will update. 

![](https://github.com/Glyceri/FFXIVPetRenamer/blob/main/res/ChoseName.png)

Select the long gray bar and type a name.
After having typed the name press [Save Name]. 

![](https://github.com/Glyceri/FFXIVPetRenamer/blob/main/res/CustomName.png)

Resummon your pet (or look away and back) and...
There he is, little JimJim! 

![](https://github.com/Glyceri/FFXIVPetRenamer/blob/main/res/JimJim.png)

You can remove a nickname at any point by clicking Remove Nickname and then resummoning your pet.