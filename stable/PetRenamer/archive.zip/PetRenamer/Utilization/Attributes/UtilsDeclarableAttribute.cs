﻿using System;

namespace PetRenamer.Utilization.Attributes;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
internal class UtilsDeclarableAttribute : Attribute { }