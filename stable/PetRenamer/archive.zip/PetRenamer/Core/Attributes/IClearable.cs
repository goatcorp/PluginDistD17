﻿namespace PetRenamer.Core.Attributes;

internal interface IClearable
{
    void Clear();
}
