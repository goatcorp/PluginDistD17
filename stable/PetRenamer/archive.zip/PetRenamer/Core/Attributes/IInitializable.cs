﻿namespace PetRenamer.Core.Attributes;

internal interface IInitializable
{
    void Initialize();
}
