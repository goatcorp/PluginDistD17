﻿using System;

namespace PetRenamer.Core.Hooking.Attributes;

[AttributeUsage(AttributeTargets.Class)]
public class HookAttribute : Attribute { }
