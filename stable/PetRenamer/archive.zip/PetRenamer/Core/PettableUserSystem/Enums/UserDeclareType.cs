﻿namespace PetRenamer.Core.PettableUserSystem.Enums;

public enum UserDeclareType
{
    Add,
    Remove,
    IPC
}
