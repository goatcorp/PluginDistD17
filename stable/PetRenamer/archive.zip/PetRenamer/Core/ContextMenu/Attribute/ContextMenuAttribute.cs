﻿using System;

namespace PetRenamer.Core.ContextMenu.Attributes;

[AttributeUsage(AttributeTargets.Class)]
public class ContextMenuAttribute : Attribute { }
