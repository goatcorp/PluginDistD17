﻿namespace PetRenamer.Core.AutoRegistry.Interfaces;

internal interface IRegistryElement { }