﻿using System;

namespace PetRenamer.Core.AutoRegistry.Interfaces;

internal interface IDisposableRegistryElement : IRegistryElement, IDisposable { }