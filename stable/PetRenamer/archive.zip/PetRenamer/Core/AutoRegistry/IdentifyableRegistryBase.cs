﻿namespace PetRenamer.Core.AutoRegistry;

internal class IdentifyableRegistryBase { }