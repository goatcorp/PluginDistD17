﻿namespace PetRenamer.Core.Sharing.Importing.Data;

public enum ImportType
{
    None,
    New,
    Rename,
    Remove,
}
