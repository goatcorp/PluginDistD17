﻿namespace PetRenamer.Core.Sharing.Importing.Data;

public abstract class ImportData { }
