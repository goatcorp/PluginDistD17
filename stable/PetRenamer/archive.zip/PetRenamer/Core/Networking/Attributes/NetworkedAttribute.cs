﻿using System;

namespace PetRenamer.Core.Networking.Attributes;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
public class NetworkedAttribute : Attribute { }
