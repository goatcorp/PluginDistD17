﻿using System;

namespace PetRenamer.Windows.Attributes;

[AttributeUsage(AttributeTargets.Class)]
public class ConfigPetWindowAttribute : Attribute { }