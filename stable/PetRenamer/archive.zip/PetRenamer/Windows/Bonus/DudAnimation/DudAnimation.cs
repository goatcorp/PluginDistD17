﻿namespace PetRenamer.Windows.Bonus;

[ToolbarAnimation("None", -2)]
internal class DudAnimation : ToolbarAnimation
{
    internal override void OnInitialize() { }
}
