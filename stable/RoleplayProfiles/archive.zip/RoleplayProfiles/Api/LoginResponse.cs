namespace RoleplayProfiles.Api
{
    public class LoginResponse
    {
        public string AccessToken { get; set; } = "";
    }
}
