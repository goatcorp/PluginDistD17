namespace RoleplayProfiles.Api
{
    public class ExtendLoginResponse
    {
        public string? NewAccessToken { get; set; } = null;
    }
}
