namespace RoleplayProfiles.Api
{
    internal class SessionResult
    {
        public string SessionToken { get; set; } = "";
    }
}
