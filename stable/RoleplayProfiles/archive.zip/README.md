# Roleplay Profiles (RPP)

Roleplay Profiles (RPP) plugin for Dalamud, the Final Fantasy XIV unofficial plugin framework.
