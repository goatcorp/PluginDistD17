# Changelog

## 1.3.1
### Added
- Option to hide items, that are not obtainable.
- Currencies that require to be in a specific location will now be hidden, if not in that area.
### Changed
- Major refactoring of some code.
- The icon for the required quest or achievement will now be colored/changed depending on the unlock status.
### Fixed
- Faux Leaves now correctly cap at 1000.
- Fixed bug that will prevent the correct display of the window when sorting.

## 1.3.0
### Added
- Societal currencies are now tracked.
- New currency: Faux leaves added.
- New currency: Achievement Certificates added.
- Added an icon with tooltip to show when a prerequisite quest is needed.
- New setting: The possibility to glue the spending windows to the main window.
### Changed
- Teleporting now skips the teleport when you are already in the correct zone.
- The spending window now only opens once shop/item data has finished loading.
- ConfigWizard reworked to work more resilient and needs less manual config.
- Refactored some code.
### Fixed
- When no sellable items are found, now shows a proper warning.

## 1.2.7
### Added
- New Currencies: Oizys Credits & Auxesia Credits.
- Highlighting for NPCs and items/menus thanks to electr0sheep.
- Option to automatically add/remove upgrade items to "Items of Interest".
### Fixed
- Select Bait Ball was missing.

## 1.2.6
### Added
- Fashion accessories can now be considered a collectable.
- Settings to hide the UI in various scenarios.
### Fixed
- Spelling errors.
### Changed
- Updated for Dalamud API v15.
- Updated ECommons.
### Removed
- Kofi Banner.

## 1.2.5
### Changed
- Updated for 7.4.
- Updated ECommons.
- Mathematics, Heliometry & Mnemonics changes.

## 1.2.4
### Added
- New Currencies: Lunar Credits & Phaenna Credits.
- New items: Everything in the Cosmic Fortunes.
- New setting to set a minimum of sales for the sellable items to display.
- Master Recipes can now be considered a collectable.
### Fixed
- NPC locations.
### Changed
- Flag/TP will now check if you need to be somewhere else or need to go there first.

## 1.2.3
### Added
- A new setting to automatically open Currency Spender together with the Currency window.
- A new button on the Currency window.
### Fixed
- Incorrect check for Framer's Kits has been resolved.
### Changed
- ECommons is now used as a NuGet package.

## 1.2.2
### Added
- New Currency: Cosmocredits.
### Changed
- Updated for 7.3.
- Updated ECommons.

## 1.2.1
### Changed
- Updated for 7.2.
- Updated ECommons.

## 1.2.0
### Added
- A check to not start the config wizard, when the plugin is newly installed.
### Changed
- Sped up the initial loading of the shops/npcs/items.
- Updated ECommons.

## 1.1.2
### Added
- A setting to toggle the display of sellable items on the market board.
- Material coffers and Triple Triad card packs added to collectables.
- Island cowries were added to the currencies.
- The Mahjong vendor, and therefore a new collectable type, was added.
- Added a context menu for items, allowing users to either link or copy the item name.
### Fixed 
- Unlock status of items should now be correctly reflected.
### Changed
- Adjustments to the Grand Company rankings to address issues with item display.

## 1.1.1
### Added
- Tooltip for Map and Teleport Buttons.
### Fixed 
- Missing NPC data for Quinnana was added.
- Default Scrip Exchange is now in Limsa Lower Decks.
### Changed
- Code Cleanup tasks.

## 1.1.0
### Added
- A setting to filter out unwanted collectables.
- A setting to filter out unwanted currencies.
- A setting to display how many selected collectables are missing directly in the main window.
- Sortable tables for all sections except ventures.
- MGP, Crafters' Scrip, Gatherers' Scrip, and Skybuilders' Scrip were added to the currency list.
- A configuration wizard to guide users through new settings.
### Fixed 
- Veteran's Clan Mark Log and Mythic Clan Mark Log were missing as sub currency.
- Grand Company seals were not correctly tracked in certain scenarios.
### Changed
- New and cleaner UI for the main window displaying the currencies.

## 1.0.5
### Fixed
- Flame and Serpent NPCs were swapped.
- Battlefield Etiquette tracking issues.
### Changed
- Rephrased the punchline and description of the plugin.

## 1.0.4
### Added
- Bicolor gemstone warnings now dynamically react to the current status of Shared Fates.
- Enhanced table styling for improved readability.
- Possibility to add items to an "Items of Interest" list.
### Fixed
- Player login logic now triggers updates automatically.
- Corrected some inaccurate locations and aetherytes.
### Changed
- Rewritten Grand Company Shop handling for better user experience.

## 1.0.3
### Added
- Plugin now shows an error message when the user is not logged in.
### Fixed
- Login routine to resolve a bug where no currencies would load.
- Minor code issues.

## 1.0.2
### Added
- Currency icon is now displayed in the table.
- Collectables and purchasable items are now displayed when another currency can be bought with it.
- A thousand separator setting.
### Removed
- Local FFXIVClientStructs.

## 1.0.1
### Fixed
- Library dependencies.
### Changed
- Code cleanup.

## 1.0.0
### Added
- Lumina utilization for data gathering.
- Teleportation button.
- More currencies.
- Ko-fi integration.
- Check for Grand Company items.
- Shared FATE checking to display only obtainable items.
- CHANGELOG.md file rendering.
### Changed
- Universalis logic.
- Collectables and tracking functionality.
- Logic rewrites to implement conditions for items/shops.

## 0.0.2
### Added
- A changelog.
- Weekly sales to the items-for-sale table.
- Faded copies to the collectables when crafted scroll is not yet unlocked.
### Changed
- Universalis handling.
### Fixed
- Barding, emotes, hairstyles, and Triple Triad cards are now correctly tracked.

## 0.0.1
### Added
- Initial release.

