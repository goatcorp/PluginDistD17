# 1.2.0.0
- Reworked the timeline layout and configuration
- Added built-in presets and a first-time setup window
- Added profiles and commands to switch between them
- Added profile import/export and a full reset option
- Existing settings are saved as a profile before choosing a new setup
- Added items, duty actions, Lost Actions, Phantom Actions, DoTs, debuffs and buffs to the timeline
- Added filters for abilities, items and effects
- Added separate lanes, new overlap options, long cooldown handling and a short ready animation
- Added Classic, split-time and full cooldown movement modes
- Added charge pips, next charge previews, priority abilities and optional game sounds
- Added GCD, cast and buff markers and improved grid labels
- Added Fade, Pop, Pulse, Breathe and Ants finish animations
- Added game fonts, separate font sizes and text shadows for timeline labels
- Added BRD DoT combining and target letters for multi-DoT tracking
- Improved cooldown and charge tracking, including abilities which reduce another ability's cooldown
- Fixed cooldown swipes and borders occasionally leaving one-pixel gaps
- Fixed fonts sometimes not being added and several timeline errors

# 1.1.0.6
- Update to API15

# 1.1.0.5
- Update to API14

# 1.1.0.4
- Update to API13

# 1.1.0.3
- Add a preview mode

# 1.1.0.2
- Fixed issue where the configuration window would sometimes open in the top-left corner of the screen
- Added support for progressive cooldown icon offset in the timeline to reduce overlap
- Added option to display segment labels in seconds instead of formatted minutes

# 1.1.0.1
- Allow cooldowns to draw independently of timeline window
- Fix timeline size being (partially) dependent on icon size 

# 1.1.0.0
- Add ability to change the timeline orientation
- Added a lot more tooltips for clarification

# 1.0.0.8
- Fix for Quest Items sometimes crashing

# 1.0.0.7
- Update to API12

# 1.0.0.6
- Allow Umbral Draw to be whitelisted/blacklisted

# 1.0.0.5
- Fix crash when using certain items

# 1.0.0.4
- Update to API11

# 1.0.0.3
- Allow whitelisting/blacklisting Sprint and Return.
- Reset cooldowns when you wipe in a fight.

# 1.0.0.2
- Fixed BRD Bloodletter under Mage's Ballad and MCH Heat Blast affecting the cooldown of Gauss Round and Ricochet.  

# 1.0.0.1
- Fixed most abilities with shared charges aside from BLU from not properly being tracked.
- Remove NIN Mudras from the timeline when Hide is used.

# 1.0.0.0
- First release.
