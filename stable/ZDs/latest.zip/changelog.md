# 1.0.0.7
- Update to API12

# 1.0.0.6
- Allow Umbral Draw to be whitelisted/blacklisted

# 1.0.0.5
- Fix crash when using certain items

# 1.0.0.4
- Update to API11

# 1.0.0.3
- Allow whitelisting/blacklisting Sprint and Return.
- Reset cooldowns when you wipe in a fight.

# 1.0.0.2
- Fixed BRD Bloodletter under Mage's Ballad and MCH Heat Blast affecting the cooldown of Gauss Round and Ricochet.  

# 1.0.0.1
- Fixed most abilities with shared charges aside from BLU from not properly being tracked.
- Remove NIN Mudras from the timeline when Hide is used.

# 1.0.0.0
- First release.